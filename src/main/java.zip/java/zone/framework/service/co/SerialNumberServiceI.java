package zone.framework.service.co;

import zone.framework.model.co.SerialNumberPO;
import zone.framework.service.BaseServiceI;

/**
 * 客户业务
 * 
 * @author 刘领献
 * 
 */
public interface SerialNumberServiceI extends BaseServiceI<SerialNumberPO> {	

}
