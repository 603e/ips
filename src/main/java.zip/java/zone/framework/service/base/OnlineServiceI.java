package zone.framework.service.base;

import zone.framework.model.base.OnlinePO;
import zone.framework.service.BaseServiceI;

/**
 * 
 * @author linux liu
 * 
 */
public interface OnlineServiceI extends BaseServiceI<OnlinePO> {

}
