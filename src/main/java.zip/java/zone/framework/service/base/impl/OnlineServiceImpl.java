package zone.framework.service.base.impl;

import zone.framework.model.base.OnlinePO;
import zone.framework.service.base.OnlineServiceI;
import zone.framework.service.impl.BaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * 
 * @author linux liu
 * 
 */
@Service
public class OnlineServiceImpl extends BaseServiceImpl<OnlinePO> implements OnlineServiceI {

}
