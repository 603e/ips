package com.hpn.service.cr;

import zone.framework.service.BaseServiceI;

import com.hpn.model.cr.CustomerPO;
/**
 * 客户业务
 * 
 * @author 刘领献
 * 
 */
public interface CustomerServiceI extends BaseServiceI<CustomerPO> {	

}
